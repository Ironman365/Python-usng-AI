import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import "https://deno.land/x/xhr@0.1.0/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { code } = await req.json();
    console.log('Executing Python code...');

    // Execute code using Piston API
    const executeResponse = await fetch('https://emkc.org/api/v2/piston/execute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        language: 'python',
        version: '3.10.0',
        files: [{
          name: 'main.py',
          content: code
        }]
      })
    });

    const result = await executeResponse.json();
    console.log('Execution result:', result);

    // Check for errors
    if (result.run?.stderr) {
      const errorOutput = result.run.stderr;
      const errorLines = errorOutput.trim().split('\n').length;

      console.log(`Error detected with ${errorLines} lines`);

      // Auto-fix if error is 5 lines or less
      if (errorLines <= 5) {
        console.log('Attempting auto-fix...');
        
        const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
        if (!LOVABLE_API_KEY) {
          throw new Error('LOVABLE_API_KEY not configured');
        }

        // Use AI to fix the code
        const aiResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${LOVABLE_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'google/gemini-2.5-flash',
            messages: [
              {
                role: 'system',
                content: 'You are a Python code fixer. Fix the provided code based on the error. Return ONLY the fixed Python code without any explanations or markdown formatting.'
              },
              {
                role: 'user',
                content: `Fix this Python code:\n\n${code}\n\nError:\n${errorOutput}\n\nReturn only the fixed code.`
              }
            ],
          }),
        });

        const aiResult = await aiResponse.json();
        const fixedCode = aiResult.choices[0].message.content.trim()
          .replace(/```python\n?/g, '')
          .replace(/```\n?/g, '');

        console.log('Code fixed by AI, re-executing...');

        // Re-execute the fixed code
        const reExecuteResponse = await fetch('https://emkc.org/api/v2/piston/execute', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            language: 'python',
            version: '3.10.0',
            files: [{
              name: 'main.py',
              content: fixedCode
            }]
          })
        });

        const reResult = await reExecuteResponse.json();
        
        return new Response(
          JSON.stringify({
            fixed: true,
            fixedCode: fixedCode,
            output: reResult.run?.stdout || '',
            error: reResult.run?.stderr || '',
            originalError: errorOutput
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Error too large to auto-fix
      return new Response(
        JSON.stringify({
          fixed: false,
          output: result.run?.stdout || '',
          error: errorOutput
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Success - no errors
    return new Response(
      JSON.stringify({
        fixed: false,
        output: result.run?.stdout || '',
        error: null
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in execute-python function:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
