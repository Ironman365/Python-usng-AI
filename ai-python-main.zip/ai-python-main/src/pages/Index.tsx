import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Play, Loader2, CheckCircle2, AlertCircle, Code2 } from "lucide-react";

const DEFAULT_CODE = `# Write your Python code here
print("Hello, World!")

# Example: Calculate factorial
def factorial(n):
    if n == 0:
        return 1
    return n * factorial(n-1)

print(f"Factorial of 5 is {factorial(5)}")`;

const Index = () => {
  const [code, setCode] = useState(DEFAULT_CODE);
  const [output, setOutput] = useState("");
  const [isRunning, setIsRunning] = useState(false);
  const [status, setStatus] = useState<"idle" | "running" | "success" | "error" | "fixed">("idle");
  const { toast } = useToast();

  const runCode = async () => {
    if (!code.trim()) {
      toast({
        title: "Error",
        description: "Please write some code first",
        variant: "destructive",
      });
      return;
    }

    setIsRunning(true);
    setStatus("running");
    setOutput("Running code...\n");

    try {
      const { data, error } = await supabase.functions.invoke("execute-python", {
        body: { code },
      });

      if (error) throw error;

      if (data.fixed) {
        setStatus("fixed");
        setCode(data.fixedCode);
        setOutput(`✓ Error detected and automatically fixed!\n\n${data.output || data.error}`);
        toast({
          title: "Code Auto-Fixed! ✓",
          description: "Small error detected and corrected automatically",
        });
      } else if (data.error) {
        setStatus("error");
        setOutput(`Error:\n${data.error}`);
        toast({
          title: "Execution Error",
          description: "Your code has errors",
          variant: "destructive",
        });
      } else {
        setStatus("success");
        setOutput(data.output || "Code executed successfully with no output");
        toast({
          title: "Success",
          description: "Code executed successfully",
        });
      }
    } catch (error: any) {
      setStatus("error");
      setOutput(`System Error: ${error.message}`);
      toast({
        title: "System Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsRunning(false);
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case "running":
        return <Loader2 className="w-5 h-5 animate-spin text-info" />;
      case "success":
        return <CheckCircle2 className="w-5 h-5 text-accent" />;
      case "fixed":
        return <CheckCircle2 className="w-5 h-5 text-accent" />;
      case "error":
        return <AlertCircle className="w-5 h-5 text-destructive" />;
      default:
        return <Code2 className="w-5 h-5 text-muted-foreground" />;
    }
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <header className="text-center space-y-2 py-8">
          <h1 className="text-4xl font-bold text-foreground flex items-center justify-center gap-3">
            <Code2 className="w-10 h-10 text-primary" />
            Python Code Executor
          </h1>
          <p className="text-muted-foreground text-lg">
            Write Python code with AI-powered auto-fix for small errors
          </p>
        </header>

        {/* Main Grid */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Code Editor */}
          <Card className="p-6 bg-card border-border space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-foreground flex items-center gap-2">
                {getStatusIcon()}
                Code Editor
              </h2>
              <Button
                onClick={runCode}
                disabled={isRunning}
                className="bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                {isRunning ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Running...
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Run Code
                  </>
                )}
              </Button>
            </div>

            <Textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="Write your Python code here..."
              className="min-h-[500px] font-mono text-sm bg-code-bg text-code-text border-code-border resize-none"
            />

            {status === "fixed" && (
              <div className="p-3 rounded-lg bg-accent/10 border border-accent text-accent-foreground text-sm">
                <CheckCircle2 className="w-4 h-4 inline mr-2" />
                Code was automatically fixed and updated above
              </div>
            )}
          </Card>

          {/* Output Console */}
          <Card className="p-6 bg-card border-border space-y-4">
            <h2 className="text-xl font-semibold text-foreground">Output Console</h2>

            <div className="bg-code-bg border border-code-border rounded-lg p-4 min-h-[500px] font-mono text-sm text-code-text whitespace-pre-wrap overflow-auto">
              {output || "Output will appear here..."}
            </div>

            {status === "fixed" && (
              <div className="flex items-start gap-3 p-4 rounded-lg bg-accent/10 border border-accent">
                <CheckCircle2 className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="font-semibold text-accent-foreground">Auto-Fix Applied</p>
                  <p className="text-sm text-muted-foreground">
                    A small error was detected and automatically corrected. The fixed code is now in the editor.
                  </p>
                </div>
              </div>
            )}

            {status === "error" && (
              <div className="flex items-start gap-3 p-4 rounded-lg bg-destructive/10 border border-destructive">
                <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="font-semibold text-destructive">Error</p>
                  <p className="text-sm text-muted-foreground">
                    Your code has errors. Large errors (&gt;5 lines) require manual fixing.
                  </p>
                </div>
              </div>
            )}
          </Card>
        </div>

        {/* Info Banner */}
        <Card className="p-6 bg-card/50 border-border">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-lg bg-primary/10">
              <Code2 className="w-6 h-6 text-primary" />
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold text-foreground">AI-Powered Error Correction</h3>
              <p className="text-sm text-muted-foreground">
                This platform automatically detects and fixes small errors (5 lines or fewer). When an error is fixed, 
                you'll see a success message and the corrected code will be updated in the editor automatically.
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Index;
